<?php

// Things to notice:
// This script is called by every other script (via include_once)
// It starts the session and displays a different set of menu links depending on whether the user is logged in or not
// It also reads in the credentials for our database connection from credentials.php

// database connection details:
require_once "credentials.php";

// our helper functions:
require_once "helper.php";

// start/restart the session:
session_start();

if (isset($_SESSION['loggedInWeek12']))
{
	// THIS PERSON IS LOGGED IN
	// show the logged in menu options:

	$username = $_SESSION["username"];
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

	// A select statement/if statement below shows that if a user is type 1 he is an admin so he has an extra header whereas if the user is type 2 he will not have an admin page
	$query = "SELECT * FROM members where username = '$username'";
	$result = mysqli_query($connection, $query);
	$row = mysqli_fetch_assoc($result);
	$type = $row['type'];

if ($type==1)
{
echo <<<_END
<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Jquery File -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!-- BootStrap File -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- Internal style for navbar with background color and color of text -->

<style>

	.navbar {
	margin-bottom: 0;
	border-radius: 0;
	background-color: #7a4085;
	color: #FFF;
	padding: 1% 0;
	font-size: 1.2em;
	border: 0;
	}
	.navbar-brand{
	float: left;
	position: absolute;
	min-height: 55px;
	padding: 0 15px 15px;
	}
	.navbar-inverse .navbar-nav .active a, .navbar-inverse .navbar-nav .active a:focus,
	.navbar-inverse .navbar-nav .active a:hover {

	color: #FFF;
	background-color: #7a4085;
	}
	.navbar-inverse .navbar-nav li a {
	color: #D5D5D5;
	}
	.carousel-caption{
	top: 50%;
	transform: translateY(-50%);
	text-transform: uppercase;
	}
	.btn{
	font-size: 18px;
	color: #FFF;
	padding: 12px 22px;
	background: #7a4085;
	border: 2px solid #FFF;
	}
	.container{
	margin: 4% auto;
	}
	#icon{
	max-width: 200px;
	margin: 1% auto;
	}

	@media (max-width: 600px){
	.carousel-caption {
	display: none;
	}
		#icon{
	max-width: 150px;
	} h2{
	font-size: 1.7em;
	}
}
</style>
</head>
<body>

<nav class = "navbar navbar-inverse"
<div class="container-fluid">
<div class="navbar-header">
    <!-- button created for phone version -->
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="index.php"> <img src="img/Logo.png"></a>
</div>

    <!-- Creating navbar and the titles -->
<div class="collapse navbar-collapse" id="myNavbar">
<ul class="nav navbar-nav navbar-right">
<li class="active"><a href="index.php">Home</a></li>
<li><a href="admin.php">Admin Control</a></li>
<li><a href="tutorial.php">Tutorials</a></li>
<li><a href="quiz.php">Tests</a></li>
<li><a href="chat.php">Global Chat</a></li>
<li><a href="sign_out.php">Sign Out ({$_SESSION['username']})</a></li>
</ul>
</div>
</div>
</nav>

_END;
}
elseif($type==2)
{
echo <<<_END
<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Jquery File -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!-- BootStrap File -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- Internal style for navbar with background color and color of text -->

<style>

	.navbar {
	margin-bottom: 0;
	border-radius: 0;
	background-color: #7a4085;
	color: #FFF;
	padding: 1% 0;
	font-size: 1.2em;
	border: 0;
	}
	.navbar-brand{
	float: left;
	position: absolute;
	min-height: 10px;
	padding: 0 15px 15px;
	}
	.navbar-inverse .navbar-nav .active a, .navbar-inverse .navbar-nav .active a:focus,
	.navbar-inverse .navbar-nav .active a:hover {

	color: #FFF;
	background-color: #7a4085;
	}
	.navbar-inverse .navbar-nav li a {
	color: #D5D5D5;
	}
	.carousel-caption{
	top: 50%;
	transform: translateY(-50%);
	text-transform: uppercase;
	}
	.btn{
	font-size: 18px;
	color: #FFF;
	padding: 12px 22px;
	background: #7a4085;
	border: 2px solid #FFF;
	}
	.container{
	margin: 4% auto;
	}
	#icon{
	max-width: 200px;
	margin: 1% auto;
	}

	@media (max-width: 600px){
	.carousel-caption {
	display: none;
	}
		#icon{
	max-width: 150px;
	} h2{
	font-size: 1.7em;
	}
}
</style>
</head>
<body>

<nav class = "navbar navbar-inverse"
<div class="container-fluid">
<div class="navbar-header">
    <!-- button created for phone version -->
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="index.php"> <img src="img/Logo.png"></a>
</div>

    <!-- Creating navbar and the titles -->
<div class="collapse navbar-collapse" id="myNavbar">
<ul class="nav navbar-nav navbar-right">
<li class="active"><a href="index.php">Home</a></li>
<li><a href="tutorial.php">Tutorials</a></li>
<li><a href="quiz.php">Tests</a></li>
<li><a href="chat.php">Global Chat</a></li>
<li><a href="show_profile.php">Profile</a></li>
<li><a href="sign_out.php">Sign Out ({$_SESSION['username']})</a></li>
</ul>
</div>
</div>
</nav>

_END;
}
}
else
{
	// THIS PERSON IS NOT LOGGED IN
	// show the logged out menu options:

echo <<<_END
<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Jquery File -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!-- BootStrap File -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- Internal style for navbar with background color and color of text -->

<style>

	.navbar {
	margin-bottom: 0;
	border-radius: 0;
	background-color: #7a4085;
	color: #FFF;
	padding: 1% 0;
	font-size: 1.2em;
	border: 0;
	}
	.navbar-brand{
	float: left;
    position: absolute;
	min-height: 55px;
	padding: 0 15px 15px;
	}
	.navbar-inverse .navbar-nav .active a, .navbar-inverse .navbar-nav .active a:focus,
	.navbar-inverse .navbar-nav .active a:hover {

	color: #FFF;
	background-color: #7a4085;
	}
	.navbar-inverse .navbar-nav li a {
	color: #D5D5D5;
	}
	.carousel-caption{
	top: 50%;
	transform: translateY(-50%);
	text-transform: uppercase;
	}
	.btn{
	font-size: 18px;
	color: #FFF;
	padding: 12px 22px;
	background: #7a4085;
	border: 2px solid #FFF;
	}
	.container{
	margin: 4% auto;
	}
	#icon{
	max-width: 200px;
	margin: 1% auto;
	}

	@media (max-width: 600px){
	.carousel-caption {
	display: none;
	}
		#icon{
	max-width: 150px;
	} h2{
	font-size: 1.7em;
	}
}
</style>
</head>
<body>

<nav class = "navbar navbar-inverse"
<div class="container-fluid">
<div class="navbar-header">
    <!-- button created for phone version -->
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="index.php"> <img src="img/Logo.png"></a>
</div>

    <!-- Creating navbar and the titles -->
<div class="collapse navbar-collapse" id="myNavbar">
<ul class="nav navbar-nav navbar-right">
<li class="active"><a href="index.php">Home</a></li>
<li><a href="tutorial.php">Tutorials</a></li>
<li><a href="quiz.php">Tests</a></li>
<li><a href="chat.php">Global Chat</a></li>
<li><a href="sign_up.php">Sign Up</a></li>
<li><a href="sign_in.php">Sign In</a></li>
</ul>
</div>
</div>
</nav>

_END;
}
?>
