<?php

// finish outputting the HTML for this page:
echo <<<_END
<br>
</body>
</html>
_END;
?>