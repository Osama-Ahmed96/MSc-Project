<?php

// execute the header script:
require_once "header.php";

if (!isset($_SESSION['loggedInWeek12']))
{
	// user isn't logged in, display a message saying they must be:
	echo "You must be logged in to view this page.<br>";
}
else
{

	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

	// if the connection fails, we need to know, so allow this exit:
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}


echo <<<_END

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Learn HTML</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Jquery File -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!-- BootStrap File -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- Internal style for navbar with background color and color of text -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<style>

.navbar {
margin-bottom: 0;
border-radius: 0;
background-color: #7a4085;
color: #FFF;
padding: 1% 0;
font-size: 1.1em;
border: 0;
font-family: arial;
}

	p {
	font-family: arial;
}

	.navbar-brand{
	float: left;
	min-height: 55px;
	padding: 0 15px 15px;
	}
	.navbar-inverse .navbar-nav .active a, .navbar-inverse .navbar-nav .active a:focus,
	.navbar-inverse .navbar-nav .active a:hover {

	color: #FFF;
	background-color: #7a4085;
	}
	.navbar-inverse .navbar-nav li a {
	color: #D5D5D5;
	}
	.carousel-caption{
	top: 50%;
	transform: translateY(-50%);
	text-transform: uppercase;
	}
	.btn{
	font-size: 18px;
	color: #FFF;
	padding: 12px 22px;
	background: #7a4085;
	border: 2px solid #FFF;
	}
	.sidenav{
		width: 10%;
    position: absolute;
		background-color: #eee;
		padding: 0 15px 15px;
		font-size: 1.1em;
		border: 0;
		font-family: arial;
	}

	.container{
	margin: 3% auto;
	margin-left: 9.5%;
	}
	#icon{
	max-width: 200px;
	margin: 1% auto;
	}

	@media (max-width: 600px){
	.carousel-caption {
	display: none;
	}
	#icon{
	max-width: 150px;
	} h2{
	font-size: 1.7em;
	}
}
</style>
</head>
<body>

<div class="sidenav">
  <a href="tutorial.php" class="w3-bar-item w3-button">Lesson 1</a>
  <a href="lessontwo.php" class="w3-bar-item w3-button">Lesson 2</a>
  <a href="lessonthree.php" class="w3-bar-item w3-button">Lesson 3</a>
  <a href="lessonfour.php" class="w3-bar-item w3-button">Lesson 4</a>
  <a href="lessonfive.php" class="w3-bar-item w3-button">Lesson 5</a>
  <a href="lessonsix.php" class="w3-bar-item w3-button">Lesson 6</a>
  <a href="lessonseven.php" class="w3-bar-item w3-button">Lesson 7</a>
  <a href="lessoneight.php" class="w3-bar-item w3-button">Lesson 8</a>
  <a href="lessonnine.php" class="w3-bar-item w3-button">Lesson 9</a>
  <a href="lessonten.php" class="w3-bar-item w3-button">Lesson 10</a>
  <a href="lessoneleven.php" class="w3-bar-item w3-button">Lesson 11</a>
  <a href="lessontwelve.php" class="w3-bar-item w3-button">Lesson 12</a>
  <a href="lessonthirteen.php" class="w3-bar-item w3-button">Lesson 13</a>
  <a href="lessonfourteen.php" class="w3-bar-item w3-button">Lesson 14</a>
  <a href="lessonfifteen.php" class="w3-bar-item w3-button">Lesson 15</a>
  <a href="lessonsixteenth.php" class="w3-bar-item w3-button">Lesson 16</a>
  <a href="lessonseventeenth.php" class="w3-bar-item w3-button">Lesson 17</a>
  <a href="lessoneighteenth.php" class="w3-bar-item w3-button">Lesson 18</a>

</div>

<h2><u><div style="text-align:center">Lesson 2</div></u></h2>
<div class="container">
<div class="col-md-9">
<h4><u>Elements</u></h4>
<p>Within this section we are covering HTML elements. An HTML element is that content/information that is inserted between start and end tags. For instance, the text “My first paragraph” on the image is an example of an HTML element. In addition, HTML elements can also be nested (meaning elements can contain other elements). Majority of HTML documents include nested HTML elements. The diagram consists of four HTML elements. </p>
<p> To explain, the “html” element outlines the entire document by the use of its opened and closed tags however the content (element) is a different HTML element, the “body” element. The “body” element outlines the document’s body by the use of the opened and closed tags however the content (element) is two different HTML elements and in this case it’s the heading “h1” and paragraph “p” tags. The “h1” element outlines a heading with its element being the content “My first heading”. On the other hand, the “p” tag outlines a paragraph with its element being the content “My first paragraph”.</p>
</div>
<div class="col-md-3">
<img src="img/Lesson2Picture1.png" class="img-responsive">
<figurecaption>
<p style="font-family:arial;"><strong> Figure 4 - </strong> Elements of HTML</p>
</figurecaption>
</div>

<div class="col-md-8">
<h4><u>Empty HTML Elements</u></h4>
<p>Furthermore, HTML elements that consist with no information/content are named empty elements. For instance, a “br” tag which outlines a line break is an empty element due to the fact that it does not need any content or a closing tag. However, empty elements can be closed within the opening tag, in this case the line break tag can be closed as “br/”. HTML doesn’t demand empty elements to be closed. However, if you need validation you will have to close all HTML elements correctly.</p>
</div>
<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
<img src="img/Lesson2Picture2.png" class="img-responsive">
<figurecaption>
<p style="font-family:arial;"><strong> Figure 5 - </strong> Empty HTML Elements</p>
</figurecaption>
</div>

<div class="col-md-8">
<h4><u>End Tag and Lowercase Tags</u></h4>
<p>An important tip to take note off is that a few HTML elements will show properly, even though you may have forgotten to put a closed tag. As well as this HTML tags aren’t case sensitive meaning that “H1” is the same as “h1”.</p>
</div>
<div class="col-md-3">
<br>
<img src="img/Lesson2Picture3.png" class="img-responsive">
<figurecaption>
<p style="font-family:arial;"><strong> Figure 6 - </strong> End Tag and Lowercase Tags</p>
</figurecaption>
</div>
</div>
</div>
</div>

</body>
</html>

_END;
}

?>
