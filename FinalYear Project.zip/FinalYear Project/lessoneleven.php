<?php

// execute the header script:
require_once "header.php";

if (!isset($_SESSION['loggedInWeek12']))
{
	// user isn't logged in, display a message saying they must be:
	echo "You must be logged in to view this page.<br>";
}
else
{

	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

	// if the connection fails, we need to know, so allow this exit:
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}


echo <<<_END

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Learn HTML</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Jquery File -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!-- BootStrap File -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- Internal style for navbar with background color and color of text -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<style>

.navbar {
margin-bottom: 0;
border-radius: 0;
background-color: #7a4085;
color: #FFF;
padding: 1% 0;
font-size: 1.1em;
border: 0;
font-family: arial;
}

	p {
	font-family: arial;
}

	.navbar-brand{
	float: left;
	min-height: 55px;
	padding: 0 15px 15px;
	}
	.navbar-inverse .navbar-nav .active a, .navbar-inverse .navbar-nav .active a:focus,
	.navbar-inverse .navbar-nav .active a:hover {

	color: #FFF;
	background-color: #7a4085;
	}
	.navbar-inverse .navbar-nav li a {
	color: #D5D5D5;
	}
	.carousel-caption{
	top: 50%;
	transform: translateY(-50%);
	text-transform: uppercase;
	}
	.btn{
	font-size: 18px;
	color: #FFF;
	padding: 12px 22px;
	background: #7a4085;
	border: 2px solid #FFF;
	}
	.sidenav{
		width: 10%;
    position: absolute;
		background-color: #eee;
		padding: 0 15px 15px;
		font-size: 1.1em;
		border: 0;
		font-family: arial;
	}

	.container{
	margin: 3% auto;
	margin-left: 9.5%;
	}
	#icon{
	max-width: 200px;
	margin: 1% auto;
	}

	@media (max-width: 600px){
	.carousel-caption {
	display: none;
	}
	#icon{
	max-width: 150px;
	} h2{
	font-size: 1.7em;
	}
}
</style>
</head>
<body>

<div class="sidenav">
  <a href="tutorial.php" class="w3-bar-item w3-button">Lesson 1</a>
  <a href="lessontwo.php" class="w3-bar-item w3-button">Lesson 2</a>
  <a href="lessonthree.php" class="w3-bar-item w3-button">Lesson 3</a>
  <a href="lessonfour.php" class="w3-bar-item w3-button">Lesson 4</a>
  <a href="lessonfive.php" class="w3-bar-item w3-button">Lesson 5</a>
  <a href="lessonsix.php" class="w3-bar-item w3-button">Lesson 6</a>
  <a href="lessonseven.php" class="w3-bar-item w3-button">Lesson 7</a>
  <a href="lessoneight.php" class="w3-bar-item w3-button">Lesson 8</a>
  <a href="lessonnine.php" class="w3-bar-item w3-button">Lesson 9</a>
  <a href="lessonten.php" class="w3-bar-item w3-button">Lesson 10</a>
  <a href="lessoneleven.php" class="w3-bar-item w3-button">Lesson 11</a>
  <a href="lessontwelve.php" class="w3-bar-item w3-button">Lesson 12</a>
  <a href="lessonthirteen.php" class="w3-bar-item w3-button">Lesson 13</a>
  <a href="lessonfourteen.php" class="w3-bar-item w3-button">Lesson 14</a>
  <a href="lessonfifteen.php" class="w3-bar-item w3-button">Lesson 15</a>
  <a href="lessonsixteenth.php" class="w3-bar-item w3-button">Lesson 16</a>
  <a href="lessonseventeenth.php" class="w3-bar-item w3-button">Lesson 17</a>
  <a href="lessoneighteenth.php" class="w3-bar-item w3-button">Lesson 18</a>

</div>

<h2><u><div style="text-align:center">Lesson 11</div></u></h2>
<div class="container">

<div class="col-md-8">
<h4><u>CSS </u></h4>
<p>Within this section we are covering CSS. The use of the abbreviation CSS stands for the term Cascading Style Sheets. The purpose of CSS is to show how HTML elements are to be presented in webpage. A huge advantage of using CSS is that it is time efficient as it saves a lot of time and work. This is because it controls how the layout of the websites all at once. They are three different ways in which CSS can be added to HTML elements. They are: Inline, Internal and External. </p>
</div>
<div class="col-md-3">
<img src="img/L11P1.png" alt="Figure 25" class="img-responsive">
<figurecaption>
<p style="font-family:arial;"><strong> Figure 25 - </strong>Different Color Values and RGB Values</p>
</figurecaption>
</div>

<div class="col-md-8">
<h4><u>Styling with HTML </u></h4>
<p>Firstly, inline uses a unique style attribute that is applied in a single HTML element. Whereas internal uses the “style” element in the “head” section single HTML page. However, external which is the most common way to include CSS within HTML and it uses an external CSS file to keep the styles separate for an entire look for a website. In addition, you will need to have a “link” element in the “head” section of the HTML page linking it to the external file. This external file cannot include HTML code and it will need to be saved as a “.css” extension. </p>
</div>
<div class="col-md-2">
<br>
<img src="img/L11P2.png" alt="Figure 26" class="img-responsive">
<figurecaption>
<p style="font-family:arial;"><strong> Figure 26 - </strong>HTML Styling</p>
</figurecaption>
</div>


<div class="col-md-8">
<h4><u>CSS Fonts</u></h4>
<p>Furthermore, as CSS controls the layout of the webpage it can change the colour of text as well as the “font-family” and “font-size” that is to be used within a webpage. This can also include “border” around HTML elements. As well as this, the padding and margin of the webpage can also be altered. It is extremely useful to include a unique “id” attribute to an element as this will allow to you specifically style that one element with the use of a unique id. On the other hand, if you want to style multiple elements you can include a “class” attribute to do so.</p>
</div>

<div class="col-md-2">
<br>
<img src="img/L11P3.png" alt="Figure 27" class="img-responsive">
<figurecaption>
<p style="font-family:arial;"><strong> Figure 27 - </strong>Various CSS Fonts</p>
</figurecaption>
</div>
</div>
</div>

</body>
</html>

_END;
}

?>
