<?php

// execute the header script:
require_once "header.php";

if (!isset($_SESSION['loggedInWeek12']))
{
	// user isn't logged in, display a message saying they must be:
	echo "You must be logged in to view this page.<br>";
}
else
{

	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

	// if the connection fails, we need to know, so allow this exit:
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}


echo <<<_END

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Learn HTML</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Jquery File -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!-- BootStrap File -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- Internal style for navbar with background color and color of text -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<style>

.navbar {
margin-bottom: 0;
border-radius: 0;
background-color: #7a4085;
color: #FFF;
padding: 1% 0;
font-size: 1.1em;
border: 0;
font-family: arial;
}

	p {
	font-family: arial;
}

	.navbar-brand{
	float: left;
	min-height: 55px;
	padding: 0 15px 15px;
	}
	.navbar-inverse .navbar-nav .active a, .navbar-inverse .navbar-nav .active a:focus,
	.navbar-inverse .navbar-nav .active a:hover {

	color: #FFF;
	background-color: #7a4085;
	}
	.navbar-inverse .navbar-nav li a {
	color: #D5D5D5;
	}
	.carousel-caption{
	top: 50%;
	transform: translateY(-50%);
	text-transform: uppercase;
	}
	.btn{
	font-size: 18px;
	color: #FFF;
	padding: 12px 22px;
	background: #7a4085;
	border: 2px solid #FFF;
	}
	.sidenav{
		width: 10%;
    position: absolute;
		background-color: #eee;
		padding: 0 15px 15px;
		font-size: 1.1em;
		border: 0;
		font-family: arial;
	}

	.container{
	margin: 3% auto;
	margin-left: 9.5%;
	}
	#icon{
	max-width: 200px;
	margin: 1% auto;
	}

	@media (max-width: 600px){
	.carousel-caption {
	display: none;
	}
	#icon{
	max-width: 150px;
	} h2{
	font-size: 1.7em;
	}
}
</style>
</head>
<body>

<div class="sidenav">
  <a href="tutorial.php" class="w3-bar-item w3-button">Lesson 1</a>
  <a href="lessontwo.php" class="w3-bar-item w3-button">Lesson 2</a>
  <a href="lessonthree.php" class="w3-bar-item w3-button">Lesson 3</a>
  <a href="lessonfour.php" class="w3-bar-item w3-button">Lesson 4</a>
  <a href="lessonfive.php" class="w3-bar-item w3-button">Lesson 5</a>
  <a href="lessonsix.php" class="w3-bar-item w3-button">Lesson 6</a>
  <a href="lessonseven.php" class="w3-bar-item w3-button">Lesson 7</a>
  <a href="lessoneight.php" class="w3-bar-item w3-button">Lesson 8</a>
  <a href="lessonnine.php" class="w3-bar-item w3-button">Lesson 9</a>
  <a href="lessonten.php" class="w3-bar-item w3-button">Lesson 10</a>
  <a href="lessoneleven.php" class="w3-bar-item w3-button">Lesson 11</a>
  <a href="lessontwelve.php" class="w3-bar-item w3-button">Lesson 12</a>
  <a href="lessonthirteen.php" class="w3-bar-item w3-button">Lesson 13</a>
  <a href="lessonfourteen.php" class="w3-bar-item w3-button">Lesson 14</a>
  <a href="lessonfifteen.php" class="w3-bar-item w3-button">Lesson 15</a>
  <a href="lessonsixteenth.php" class="w3-bar-item w3-button">Lesson 16</a>
  <a href="lessonseventeenth.php" class="w3-bar-item w3-button">Lesson 17</a>
  <a href="lessoneighteenth.php" class="w3-bar-item w3-button">Lesson 18</a>

</div>

<h2><u><div style="text-align:center">Lesson 15</div></u></h2>
<div class="container">

<div class="col-md-9">
<h4><u>Lists</u></h4>
<p>Within this section we are covering HTML Lists. In HTML, lists are outlined with the use of the opened and closed “ul” tags, which makes an unordered list. However listed items are outlined with the use of the opened and closed “li” tags. By default, bullet points are used to mark listed items. But to style the listed items into squares or circles you will need to use the CSS “list-style-type” property as shown in the diagram. On the other hand, an ordered list is outlined with the use of the opened and closed “ol” tags and just like unordered lists the listed items use the “li” tags. However, we use the attribute “type” to style the type of the listed item meaning it can either be numbered or uses alphabets. </p>
</div>
<div class="col-md-2">
<img src="img/L15P1.png" class="img-responsive">
<figurecaption>
<p style="font-family:arial;"><strong> Figure 36 - </strong>View of lists</p>
</figurecaption>
</div>


<div class="col-md-9">
<h4><u>Description Lists</u></h4>
<p>Additionally, description lists can also be used to which has a listed of items that include a description of what the items are. The tag “dl” is used to outline the description list but the use of the “dt” tag outlines the name of the listed items whereas the “dd” tag outlines the description of what the items are. This is shown in the diagram. To add, lists can have lists within each other and we call this a nested list. These lists can be any type of an HTML element such as an image.</p>
</div>
<div class="col-md-2">
<br>
<img src="img/L15P2.png" class="img-responsive">
<figurecaption>
<p style="font-family:arial;"><strong> Figure 37 - </strong>Description Lists</p>
</figurecaption>
</div>

<div class="col-md-9">
<h4><u>Control List Counting</u></h4>
<p>Finally, when ordering a list by default you will begin counting from 1 but this can be changed by the use of the “start” attribute that allows you to start from your specified number. Also, HTML lists can be styled using CSS. For example, most commonly lists are styled horizontally and this is due to the creation of navigation menu.</p>
</div>
<div class="col-md-2">
<br>
<img src="img/L15P3.png" class="img-responsive">
<p style="font-family:arial;"><strong> Figure 38 - </strong> List Counting</p>
<figurecaption>
</figurecaption>
</div>
</div>
</div>

</body>
</html>

_END;
}

?>
