<?php

// execute the header script:
require_once "header.php";

if (!isset($_SESSION['loggedInWeek12']))
{
	// user isn't logged in, display a message saying they must be:
	echo "You must be logged in to view this page.<br>";
}
else
{

	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

	// if the connection fails, we need to know, so allow this exit:
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}

$username = $_SESSION["username"];

echo <<<_END

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Learn HTMLs</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Jquery File -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!-- BootStrap File -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- Internal style for navbar with background color and color of text -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>

.navbar {
margin-bottom: 0;
border-radius: 0;
background-color: #7a4085;
color: #FFF;
padding: 1% 0;
font-size: 1.1em;
border: 0;
font-family: arial;
}

	p {
	font-family: arial;
}
	.navbar-brand{
	float: left;
	min-height: 55px;
	padding: 0 15px 15px;
	}
	.navbar-inverse .navbar-nav .active a, .navbar-inverse .navbar-nav .active a:focus,
	.navbar-inverse .navbar-nav .active a:hover {

	color: #FFF;
	background-color: #7a4085;
	}
	.navbar-inverse .navbar-nav li a {
	color: #D5D5D5;
	}
	.carousel-caption{
	top: 50%;
	transform: translateY(-50%);
	text-transform: uppercase;
	}
	.btn{
	font-size: 18px;
	color: #FFF;
	padding: 12px 22px;
	border: 2px solid #FFF;
	}
	.sidenav{
		width: 10%;
    position: absolute;
		background-color: #eee;
		padding: 0 20px 15px;
		font-size: 1.1em;
		border: 0;
		font-family: arial;
	}

	.container{
	margin: 1% auto;
	margin-left: 13%;
	}

	.question{
	font-size: 1.0em;
	}

	.answers{
	font-size: 0.9em;
	}

	#icon{
	max-width: 200px;
	margin: 1% auto;
	}

	@media (max-width: 600px){
	.carousel-caption {
	display: none;
	}
	#icon{
	max-width: 150px;
	} h2{
	font-size: 1.7em;
	}

}
</style>
</head>
<body>

<div class="sidenav">
  <a href="quiz.php" class="w3-bar-item w3-button">Test 1</a>
  <a href="quiztwo.php" class="w3-bar-item w3-button">Test 2</a>
  <a href="quizthree.php" class="w3-bar-item w3-button">Test 3</a>
  <a href="quizfour.php" class="w3-bar-item w3-button">Test 4</a>
  <a href="quizfive.php" class="w3-bar-item w3-button">Test 5</a>
  <a href="quizsix.php" class="w3-bar-item w3-button">Test 6</a>
  <a href="quizseven.php" class="w3-bar-item w3-button">Test 7</a>
  <a href="quizeight.php" class="w3-bar-item w3-button">Test 8</a>
  <a href="quiznine.php" class="w3-bar-item w3-button">Test 9</a>
  <a href="quizten.php" class="w3-bar-item w3-button">Test 10</a>
  <a href="quizeleven.php" class="w3-bar-item w3-button">Test 11</a>
  <a href="quiztwelve.php" class="w3-bar-item w3-button">Test 12</a>
  <a href="quizthirteen.php" class="w3-bar-item w3-button">Test 13</a>
  <a href="quizfourteen.php" class="w3-bar-item w3-button">Test 14</a>
  <a href="quizfifteen.php" class="w3-bar-item w3-button">Test 15</a>
  <a href="quizsixteenth.php" class="w3-bar-item w3-button">Test 16</a>
  <a href="quizseventeenth.php" class="w3-bar-item w3-button">Test 17</a>
  <a href="quizeighteenth.php" class="w3-bar-item w3-button">Test 18</a>
</div>


<div class="container">
<div class="row">
<div class="col-md-10">
<h2><u><div style="text-align:center">Test 10</div></u></h2>
<br>
<form name="myform">
<p class="question"><u>1. What different ways are there to specify HTML colours?</u></p>

<ul class="answers">
<p style="font-family:arial;"><input type="radio" name="q1" value="a" id="q1a"><label for="q1a">RGBA, XEH, HASL</label><br>
<p style="font-family:arial;"><input type="radio" name="q1" value="b" id="q1b"><label for="q1b">RGBA, RGB, HSL</label><br>
<p style="font-family:arial;"><input type="radio" name="q1" value="c" id="q1c"><label for="q1c">HSLA, RGBA, RBG</label>&nbsp;
</ul>


<p class="question"><u>2. These colours can set which different HTML elements?</u></p>

<ul class="answers">
<p style="font-family:arial;"><input type="radio" name="q2" value="a" id="q2a"><label for="q2a">Background colour or text colour</label><br>
<p style="font-family:arial;"><input type="radio" name="q2" value="b" id="q2b"><label for="q2b">Border colour or text colour</label><br>
<p style="font-family:arial;"><input type="radio" name="q2" value="c" id="q2c"><label for="q2c">Page colour or text colour</label>
</ul>

<p class="question"><u>3. Select which of the following is a HEX value.</u></p>

<ul class="answers">
<p style="font-family:arial;"><input type="radio" name="q3" value="a" id="q3a"><label for="q3a">#ff6347</label><br>
<p style="font-family:arial;"><input type="radio" name="q3" value="b" id="q3b"><label for="q3b">(9, 100%, 64%)</label><br>
<p style="font-family:arial;"><input type="radio" name="q3" value="c" id="q3c"><label for="q3c">(255,99,71)</label>&nbsp;
</ul>

<p class="question"><u>4. For the formula using RGB what does each parameter describe?</u></p>

<ul class="answers">
<p style="font-family:arial;"><input type="radio" name="q4" value="a" id="q4a"><label for="q4a">The concentration of the colour between the digits “0” till “255”</label>&nbsp;
<p style="font-family:arial;"><input type="radio" name="q4" value="b" id="q4b"><label for="q4b">The concentration of the colour between the digits “0” till “150” </label>&nbsp;
<p style="font-family:arial;"><input type="radio" name="q4" value="c" id="q4c"><label for="q4c">The concentration of the colour between the digits “0” till “215”</label>&nbsp;
</ul>

<p class="question"><u>5. What must be formed if you wish to select a colour using the HEX form?</u></p>

<ul class="answers">
<p style="font-family:arial;"><input type="radio" name="q5" value="a" id="q5a"><label for="q5a">A decimal value</label><br>
<p style="font-family:arial;"><input type="radio" name="q5" value="b" id="q5b"><label for="q5b">A hexadecimal value</label><br>
<p style="font-family:arial;"><input type="radio" name="q5" value="c" id="q5c"><label for="q5c">A concentration of colours</label><br>
</ul>

<p class="question"><u>6. Select the correct statement, the letters in the value “#rrggbb” each represent a colour?</u></p>

<ul class="answers">
<p style="font-family:arial;"><input type="radio" name="q6" value="a" id="q6a"><label for="q6a">Yes they do</label><br>
<p style="font-family:arial;"><input type="radio" name="q6" value="b" id="q6b"><label for="q6b">No they do not</label>&nbsp;
</ul>

<p class="question"><u>7.What does HSL stand for?</u></p>

<ul class="answers">
<p style="font-family:arial;"><input type="radio" name="q7" value="a" id="q7a"><label for="q7a">Hue, setting , lightness</label><br>
<p style="font-family:arial;"><input type="radio" name="q7" value="b" id="q7b"><label for="q7b">Hexa, saturation, lightness</label><br>
<p style="font-family:arial;"><input type="radio" name="q7" value="c" id="q7c"><label for="q7c">Hue, saturation, lightness </label>
</ul>

<p class="question"><u>8. The HSL value is classed as?</u></p>

<ul class="answers">
<p style="font-family:arial;"><input type="radio" name="q8" value="a" id="q8a"><label for="q8a">A hexadecimal value</label><br>
<p style="font-family:arial;"><input type="radio" name="q8" value="b" id="q8b"><label for="q8b">A degree from 0 to 360</label><br>
<p style="font-family:arial;"><input type="radio" name="q8" value="c" id="q8c"><label for="q8c">A concentration of colour</label>
</ul>

<p style="font-family:arial;"><input type="button" value="Show me the answers" onclick="check()">
</form>

<script>
		var teststate;
	function check(){

		var var1=0;
		var score;
		var q1=document.myform.q1.value;
		var q2=document.myform.q2.value;
		var q3=document.myform.q3.value;
		var q4=document.myform.q4.value;
		var q5=document.myform.q5.value;
		var q6=document.myform.q6.value;
		var q7=document.myform.q7.value;
		var q8=document.myform.q8.value;
		var count=0;


		if(q1=="b"){
			count++;
		}
		if(q2=="a"){
			count++;
		}
		if(q3=="a"){
			count++;
		}
		if(q4=="a"){
			count++;
		}
		if(q5=="b"){
			count++;
		}
		if(q6=="a"){
			count++;
		}
		if(q7=="c"){
			count++;
		}
		if(q8=="b"){
			count++;
		}
		alert("You got "+count+" marks");

		$.ajax({
		url: 'quiz.php',
		type: 'POST',
		data: {var1: count},
		success: function(data) {
		console.log("success");
		}
		});

_END;
		if (isset($_POST['var1']))
		{
		$query = "INSERT INTO score (username,score) VALUES ('$username', '".$_POST['var1']."')";
		$result = mysqli_query($connection, $query);
		}

echo <<<_END
teststate = "going";
}
</script>

</div>
</div>

</body>
</html>

_END;
}

?>
