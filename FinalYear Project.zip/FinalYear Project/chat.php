<?php

// Things to notice:
// The main job of this script is to request the N most recent favourite numbers from the API and display them
// On a successful call to the API (recent.php) the jQuery deletes any old rows in the table and replaces them with the latest data
// The checkForFavourites() function is called again regardless of success/failure
// Right-click and "inspect" in Chrome in order to see the JavaScript debug

// execute the header script:
require_once "header.php";

// how many milliseconds to wait between updates:
$milliseconds = 5000;
// how many recent favourites to display:
$nrows = 10;

if (!isset($_SESSION['loggedInWeek12']))
{
	// user isn't logged in, display a message saying they must be:
	echo "You must be logged in to view this page.<br>";
}
else
{
	// connect directly to our database (notice 4th argument) we need the connection for sanitisation	
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	// if the connection fails, we need to know, so allow this exit:
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}
	
	$query = "SELECT * FROM members where username = '$username'"; //a select query is created which selects all the users' username from the members table
	$result = mysqli_query($connection, $query); //this query returns data
	$mute = mysqli_fetch_assoc($result);
	$mute = $mute['muted'];
	

	if(ISSET($_POST['post']))
	{
	// take a copy of the value the user has submitted and sanitise/clean it
	$post = sanitise($_POST['post'], $connection);
	}
	
	if(ISSET($_POST['post']))
	{
	// now validate the data (int must be between 0/140)
	$post_val = validateString($post, 0, 140);
	}
	else
	{
		$post_val = "";
	}
	
	// check that all the validation tests passed before going to the database:
		if(ISSET($_POST['post']))
		{
		// read their username from the session:
		$username = $_SESSION["username"];
								
			// we need an INSERT (leaving the update timestamp empty causes MySQL to use the current time):
			$query = "INSERT INTO post (username, post, likes) VALUES ('$username', '$post', 0)"; //a insert query is created which inputs data into username, post and likes
			$result = mysqli_query($connection, $query); //this query returns data	
			
		// no data returned, we just test for true(success)/false(failure):
		if ($result) 
		{
			$message = "post successfully updated<br>"; // shows a successful message
		} 
		else
		{
			$message = "Update failed<br>"; // shows an unsuccessful message
		}
		header("Location: chat.php"); //this stops duplication of messages that are written on the chat when refreshed by redirecting you to the same page
		}
	
	$query2 = "SELECT * FROM post ORDER BY posted DESC"; //a select query is created to find all favourite numbers and have them ordered by their last update time (descending)
	$result2 = mysqli_query($connection, $query2);	// this query can return data 
				
if ($mute=='0')
{
//Below is a form that is created that enables users to enter/input, comment/post new feeds into the global feed
echo <<<_END
<form action="chat.php" method="post">
  Enter your new post:<br>
	<input type="text" name="post" maxlength="140" value="" required> $post_val
  <br>
  <input type="submit" value="Submit">
</form>	
_END;
}
else{
	$message = "You are unable to post any comments because you have been muted<br>"; //This message is outputed from the form when the user is muted and is unable to post comments
	echo $message;
}
	
// CSS to make the table clearly visible, and jQuery to control updates:
echo <<<_END
<style>
	table, th, td {border: 1px solid black; align: center;}
<link rel="stylesheet" type="text/css" href="ProjectStyle.css"> <!--HTML page linked to CSS Style sheet-->	

</style>
<table id='post'>
<tr><th>User</th><th>Post</th><th>Updated</th><th>Likes</th></tr>
</table>

<script>
$(document).ready(function()
{
	$(document).on("click","#post a",function(){
	// user just clicked a "like" link, prevent default behaviour:
		event.preventDefault(); 
		console.log("clicked"); 
		
		// make a javascript object to hold our request data:
		var request = {};
		request["post_id"] = $(this).data('post_id');
		
		$.post('api/like.php', request)
		.done(function(data) {
			// debug message to help during development:
			console.log('request successful')
			
			// update the relevant user's likes number by one:
			var currentLikes = parseInt($('#' + data.post_id + ' .like').text(),10);
			var newLikes = currentLikes + 1;
			$('#' + data.post_id + ' .like').text(newLikes);
				
		})
		.fail(function(jqXHR) {
			// debug message to help during development:
			console.log('request returned failure, HTTP status code ' + jqXHR.status);
		})
		.always(function() {
			// debug message to help during development:
			console.log('request completed');
		});
    
	});
	// as soon as the page is ready, start checking for updates:
	checkForPosts();
});

function checkForPosts(){

$.getJSON('api/recent.php', {number: $nrows})
.done(function(data) {
// debug message to help during development:
console.log('request successful');

// remove the old table rows:
$('.result').remove();

// loop through what we got and add it to the table (data is already a JavaScript object thanks to getJSON()):
$.each(data, function(index, value) {
$('#post').append("<tr class='result'><td>" + value.username + "</td><td>" + value.post + "</td><td>" + value.posted + "</td><td>" + value.likes + "</td>	<td>" + "<a	data-post_id='"+value.post_id+"'>+</a></td></tr>");
});
})
.fail(function(jqXHR) {
// debug message to help during development:
console.log('request returned failure, HTTP status code ' + jqXHR.status);
})
.always(function() {
// debug message to help during development:
console.log('request completed');
// call this function again after a brief pause:
setTimeout(checkForPosts, $milliseconds);
});
}

</script>
_END;

// we're finished, close the connection:
	mysqli_close($connection);
}

?>