<?php

// Things to notice:
// client-side validation using "password","text" inputs and "required","maxlength" attributes (but we can't rely on it happening!)
// we sanitise the user's credentials - see helper.php (included via header.php) for the sanitisation function
// we validate the user's credentials - see helper.php (included via header.php) for the validation functions
// the validation functions all follow the same rule: return an empty string if the data is valid...
// ... otherwise return a help message saying what is wrong with the data.
// if validation of any field fails then we display the help messages (previous point) when re-displaying the form
// The main job of this script is to execute an INSERT statement to add the submitted username and password

// execute the header script:
require_once "header.php";

// default values we show in the form:
$show_set_form = true;
// strings to hold any validation error messages:
$username_val = "";
$password_val = "";

// should we show the signup form?:
$show_signup_form = false;
// message to output to user:
$message = "";

if (!isset($_SESSION['loggedInWeek12']))
{
	// user is already logged in, just display a message:
	echo "You are already logged in, please log out first<br>";
	
}
else
{
	// user just tried to sign up:
	
	// connect directly to our database (notice 4th argument) we need the connection for sanitisation:
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	// if the connection fails, we need to know, so allow this exit:
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}	
	
	$query = "SELECT username FROM members ORDER BY username ASC";
	
	// this query can return data ($result is an identifier):
	$result = mysqli_query($connection, $query);
	
	// how many rows came back? (can only be 1 or 0 because username is the primary key in our table):
	$n = mysqli_num_rows($result);
	
			echo "<table id='Users'>";
		echo "<tr><th>All User</th></tr>";
		// loop over all rows, adding them into the table:
		for ($i=0; $i<$n; $i++)
		{
			// fetch one row as an associative array (elements named after columns):
			$row = mysqli_fetch_assoc($result);
			
			// read the values out here to keep the HTML below more readable:
			$username = $row['username'];
			
			// add it as a row in our table:
			echo "<tr id='$username'>";
			echo "<td>$username</td>";
			echo "</tr>";
		}
		echo "</table>";
	
echo <<<_END
<form action="users.php" method="post">
  <br>Enter Username:<br>
	<input type="text" name="users" maxlength="16" value="" required>
  <br>
  <input type="submit" value="Submit">
</form>	
_END;


if(ISSET($_POST['users']))
	{
	$users=sanitise($_POST['users'], $connection);


// check for a row in our profiles table with a matching username:
	$query1 = "SELECT * FROM profiles WHERE username='$users'";
	
	// this query can return data ($result is an identifier):
	$result1 = mysqli_query($connection, $query1);
	
	// how many rows came back? (can only be 1 or 0 because username is the primary key in our table):
	$usernum = mysqli_num_rows($result1);
		
	// if there was a match then extract their profile data:
	if ($usernum > 0)
	{
		// use the identifier to fetch one row as an associative array (elements named after columns):
		$row = mysqli_fetch_assoc($result1);
		// display their profile data:
		echo "<br>First name: {$row['firstname']}<br>";
		echo "Last name: {$row['lastname']}<br>";
		echo "Age: {$row['age']}<br>";
		echo "Email address: {$row['email']}<br>";
		echo "Date of birth: {$row['dob']}<br>";
	}
	else
	{
		// no match found, prompt user to set up their profile:
		echo "Specific user still needs to set up a profile!<br>";
	}

	
	// check for a row in our profiles table with a matching username:
	$query2 = "SELECT * FROM post WHERE username='$users'";
	
	// this query can return data ($result is an identifier):
	$result2 = mysqli_query($connection, $query2);
	
	// how many rows came back? (can only be 1 or 0 because username is the primary key in our table):
	$usersfeed = mysqli_num_rows($result2);
	
	if ($usersfeed > 0)
	{
	echo "<table id='users'>";
	echo "<br><tr><th>User</th><th>Post</th><th>Posted</th><th>Likes</th><th></th></tr>";
		// loop over all rows, adding them into the table:
		for ($i=0; $i<$usersfeed; $i++)
		{
			// fetch one row as an associative array (elements named after columns):
			$row = mysqli_fetch_assoc($result2);
			
			// read the values out here to keep the HTML below more readable:
			$username = $row['username'];
			$post = $row['post'];
			$likes = $row['likes'];
			$posted = $row['posted'];
			
			// add it as a row in our table:
			echo "<tr id='$username'>";
			echo "<td>$username</td>";
			echo "<td>$post</td>";
			echo "<td>$posted</td>";
			echo "<td class='like'>$likes</td>";
			echo "</tr>";
		}
		echo "</table>";
		
		}
	else
	{
		// no match found, prompt user to set up their profile:
		echo "<br>Specific user has not posted any comments<br>";
	}
	}
		
	// we're finished with the database, close the connection:
	mysqli_close($connection);

echo <<<_END
	<style>
	table, th, td {border: 1px solid black; align: center;}
</style>
<table id='users'>
</table>
_END;

}
// display our message to the user:
echo $message;

// finish off the HTML for this page:
require_once "footer.php";

?>