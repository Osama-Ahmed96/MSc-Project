<?php

// Things to notice:
// NEW: reset the number of likes if a user changes their number
// client-side validation using "number" input and "required","min","max" attributes (but we can't rely on it happening!)
// we sanitise the user's number - see helper.php (included via header.php) for the sanitisation function
// we validate the user's number - see helper.php (included via header.php) for the validation functions
// The main job of this script is to execute an UPDATE or INSERT statement to set the user's favourite number
// (A user can sign up without specifying a favourite number, so there may or may not be a number to update)

// execute the header script:
require_once "header.php";

// should we show the set favourite number form?:
$show_set_form = true;
// message to output to user:
$message = "";
// the minimum and maximum numbers we will allow 

if (!isset($_SESSION['loggedInWeek12']))
{
	// user isn't logged in, display a message saying they must be:
	echo "You must be logged in to view this page.<br>";
}
else
{
	// user just tried to update their favourite number:
	
	// connect directly to our database (notice 4th argument) we need the connection for sanitisation:
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	// if the connection fails, we need to know, so allow this exit:
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}
	
	
	if (ISSET($_POST['MuteUser']))
	{	
		$MuteUser = sanitise($_POST['MuteUser'], $connection);
		$query = "Update members set muted = '1' where username = '$MuteUser'";
		$result = mysqli_query($connection, $query);		
	
		// no data returned, we just test for true(success)/false(failure):
		if ($result) 
		{
			// show a successful update message:
			$message = "User has been muted<br>";
		} 
		else
		{
			// show an unsuccessful update message:
			$message = "unfortunately you failed at muting the user<br>";
		}
		}
		
		if (ISSET($_POST['UnmuteUser']))
	{	
		$UnmuteUser = sanitise($_POST['UnmuteUser'], $connection);
		$query1 = "Update members set muted = '0' where username = '$UnmuteUser'";
		$result1 = mysqli_query($connection, $query1);		
	
		// no data returned, we just test for true(success)/false(failure):
		if ($result1) 
		{
			// show a successful update message:
			$message = "User have been unmuted<br>";
		} 
		else
		{
			// show an unsuccessful update message:
			$message = "unfortunately you failed at unmuting the user<br>";
		}
	}
	}


// we're finished, close the connection:
mysqli_close($connection);	

if ($show_set_form)
{
// show the form that allows users to log in
// Note we use an HTTP POST request to avoid their password appearing in the URL:

echo <<<_END
<form action="admin.php" method="post">
  Enter username to muted user:<br>
	<input type="text" name="MuteUser" value="" required> 
  <br>
  <input type="submit" value="Submit">
</form>	
_END;

echo <<<_END
<form action="admin.php" method="post">
  Enter username to unmuted user:<br>
	<input type="text" name="UnmuteUser" value="" required>
  <br>
  <input type="submit" value="Submit">
</form>	
_END;
}


// display our message to the user:
echo $message;

// finish of the HTML for this page:
require_once "footer.php";
?>